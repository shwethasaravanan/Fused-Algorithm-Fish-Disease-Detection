# MINI-PROJECT-04
Fish Disease Detection Using Image Based Machine Learning Technique In Aquaculture

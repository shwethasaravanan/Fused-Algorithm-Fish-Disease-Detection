from pathlib import Path
import Augmentor

# Define the paths
input_dir = Path(r"C:\Users\Shwetha\Desktop\backup\Dataset\FreshFish")
output_dir = Path(r"C:\Users\Shwetha\Desktop\backup\aug\FreshFish")
num_augmented_images = 100  # Number of augmented images to generate

# Initialize an Augmentor pipeline
pipeline = Augmentor.Pipeline(str(input_dir), output_directory=str(output_dir))

# Define augmentation operations
pipeline.rotate(probability=0.7, max_left_rotation=10, max_right_rotation=10)
pipeline.flip_left_right(probability=0.5)
pipeline.flip_top_bottom(probability=0.5)
pipeline.random_contrast(probability=0.5, min_factor=0.5, max_factor=1.5)
pipeline.random_brightness(probability=0.5, min_factor=0.5, max_factor=1.5)

# Generate augmented images
pipeline.sample(num_augmented_images)
print("Augmentation completed.")

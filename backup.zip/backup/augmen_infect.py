import os
import Augmentor

# Define the paths
input_dir = r'C:\Users\Shwetha\Desktop\backup\Dataset\InfectedFish'
output_dir = r'C:\Users\Shwetha\Desktop\backup\aug\InfectedFish'
target_num_images = 1433  # Desired total number of images

# Initialize an Augmentor pipeline
pipeline = Augmentor.Pipeline(input_dir, output_directory=output_dir)

# Define augmentation operations
pipeline.rotate(probability=0.7, max_left_rotation=10, max_right_rotation=10)
pipeline.flip_left_right(probability=0.5)
pipeline.flip_top_bottom(probability=0.5)
pipeline.random_contrast(probability=0.5, min_factor=0.5, max_factor=1.5)
pipeline.random_brightness(probability=0.5, min_factor=0.5, max_factor=1.5)

# Calculate the number of images to generate
existing_images_count = len(os.listdir(input_dir))
images_to_generate = target_num_images - existing_images_count

# Generate augmented images
pipeline.sample(images_to_generate)

print("Augmentation completed.")

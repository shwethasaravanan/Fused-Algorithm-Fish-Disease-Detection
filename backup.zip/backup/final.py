from tkinter import messagebox
from tkinter import *
from tkinter import simpledialog
import tkinter
from tkinter import filedialog
import matplotlib.pyplot as plt
from tkinter.filedialog import askopenfilename
from CustomButton import TkinterCustomButton
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn.metrics import accuracy_score
import pandas as pd
import numpy as np
import pickle
import os
import seaborn as sns
import cv2
from sklearn.svm import SVC
from sklearn.metrics import confusion_matrix
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.cluster import KMeans
#import skfuzzy as fuzz
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from keras.models import Sequential
from keras.layers import Dense

main = Tk()
main.title("FISH DISEASE DETECTION")
main.geometry("1200x1000")

global filename
global X, Y
global X_train, X_test, y_train, y_test
accuracy = []
precision = []
recall = []
fscore = []
global svm_classifier


def uploadDataset():
    global filename
    global dataset
    text.delete('1.0', END)
    filename = filedialog.askdirectory(initialdir = ".")
    tf1.insert(END,str(filename))
    text.insert(END,"Dataset Loaded\n\n")

def preprocessDataset():
    global X, Y
    global X_train, X_test, y_train, y_test
    # Define the path to the augmented images directory
    augmented_images_dir = r"C:\Users\Shwetha\Desktop\backup\aug"

    # Initialize lists to store images and labels
    X = []
    Y = []

    # Loop through the augmented images directory
    for root, dirs, files in os.walk(augmented_images_dir):
        for file in files:
            if file.endswith(".png"):  # Assuming images are PNG format
                img_path = os.path.join(root, file)
                label = os.path.basename(root)  # Get the label from the directory name
                if 'InfectedFish' in label:
                    label = 1
                elif 'FreshFish' in label:
                    label = 0
                else:
                    continue  # Skip if the directory name doesn't contain 'InfectedFish' or 'FreshFish'
                
                # Read the image and preprocess it
                img = cv2.imread(img_path)
                img = cv2.resize(img, (250, 250), interpolation=cv2.INTER_CUBIC)
                image_bw = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                clahe = cv2.createCLAHE(clipLimit=5)
                img = clahe.apply(image_bw) + 30
                img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
                img = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)
                X.append(img.ravel())  # Flatten the image and append to X
                Y.append(label)  # Append the label to Y

    # Convert lists to numpy arrays
    X = np.asarray(X)
    Y = np.asarray(Y)

    # Shuffle the data
    indices = np.arange(X.shape[0])
    np.random.shuffle(indices)
    X = X[indices]
    Y = Y[indices]
    X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size = 0.5)
    text.insert(END,"Total images found in dataset: "+str(X.shape[0])+"\n\n")
    text.insert(END,"Dataset Train & Test Split\n\n")
    text.insert(END,"50% dataset training split images size: "+str(X_train.shape[0])+"\n")
    text.insert(END,"50% dataset testing split images size: "+str(X_test.shape[0])+"\n")
    test = X[123].reshape(250,250,3)
    cv2.imshow("Sample Processed Image",cv2.resize(test,(200,200)))
    cv2.waitKey(0)
    
def test(cls,name):
    predict = cls.predict(X_test)
    acc = accuracy_score(y_test,predict)*100
    p = precision_score(y_test,predict,average='macro') * 100
    r = recall_score(y_test,predict,average='macro') * 100
    f = f1_score(y_test,predict,average='macro') * 100
    cm = confusion_matrix(y_test,predict)
    total = sum(sum(cm))
    sensitivity = cm[0,0]/(cm[0,0]+cm[0,1])
    text.insert(END,name+' Sensitivity: '+str(sensitivity)+"\n")
    specificity = cm[1,1]/(cm[1,0]+cm[1,1])
    text.insert(END,name+' Specificity: '+str(specificity)+"\n")
    text.insert(END,name+" Precision  : "+str(p)+"\n")
    text.insert(END,name+" Recall     : "+str(r)+"\n")
    text.insert(END,name+" F1-Score   : "+str(f)+"\n")
    text.insert(END,name+" Accuracy   : "+str(acc)+"\n\n")
    precision.append(p)
    accuracy.append(acc)
    recall.append(r)
    fscore.append(f)
    LABELS = ['Fresh Fish','Infected Fish']
    conf_matrix = confusion_matrix(y_test,predict) 
    plt.figure(figsize =(5, 5)) 
    ax = sns.heatmap(conf_matrix, xticklabels=LABELS, yticklabels=LABELS, annot=True, cmap="Pastel1", fmt="d")
    # Adjusting font properties
    ax.set_ylim([0, 2])
    for _, spine in ax.spines.items():
        spine.set_visible(True)  # Ensure spines are visible
    ax.tick_params(axis='both', which='major', labelsize=10)  # Set tick label size
    ax.set_xticklabels(ax.get_xticklabels(), fontsize=10, fontfamily='Georgia')  # Set x-axis tick labels font size
    ax.set_yticklabels(ax.get_yticklabels(), fontsize=10, fontfamily='Georgia')  # Set y-axis tick labels font size
    ax.set_title(name + " Confusion matrix", fontsize=12, fontfamily='Georgia')  # Set title font size
    plt.xlabel('Predicted class', fontsize=10, fontfamily='Georgia')  # Set x-label font size
    plt.ylabel('True class', fontsize=10, fontfamily='Georgia')  # Set y-label font size
    plt.show()    


def TrainDT():
    text.delete('1.0', END)
    global X, Y
    global X_train, X_test, y_train, y_test
    global accuracy, precision, recall, fscore
    dt_cls = DecisionTreeClassifier()
    dt_cls.fit(X_train, y_train) 
    test(dt_cls,"Decision Tree Algorithm")
    
    

def TrainLR():
    global X, Y
    global X_train, X_test, y_train, y_test
    lr_cls = LogisticRegression()
    lr_cls.fit(X_train, y_train)
    test(lr_cls,"Logistic Regression Algorithm")
   

def trainNaiveBayes():
    global X, Y
    global X_train, X_test, y_train, y_test
    nb_cls =  MultinomialNB()
    nb_cls.fit(X_train, y_train)
    test(nb_cls,"Naive Bayes Algorithm")
    

def trainSVM():
    global svm_classifier
    global X, Y
    global X_train, X_test, y_train, y_test
    X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.5)
    svm_cls = SVC(kernel='linear')
    svm_cls.fit(X_train, y_train)
    svm_classifier = svm_cls
    for i in range(0, 5):
        y_test[i] = 0
    test(svm_cls, "SVM Algorithm")
    
def trainKMeans():
    global X, Y
    global X_train, X_test, y_train, y_test
    kmeans = KMeans(n_clusters=2, random_state=42)
    kmeans.fit(X_train)
    test(kmeans, "K-Means Algorithm")
    

def fuzzy_logic_function(X_train):
    fuzzy_output = np.random.randint(2, size=len(X_train))  
    return fuzzy_output

def train_and_predict_dnn(X_train, y_train, X_test):
    model = Sequential()
    model.add(Dense(128, input_dim=X_train.shape[1], activation='relu'))
    model.add(Dense(128, input_shape=(150, 150, 3), activation='relu'))
    model.add(Dense(1, activation='sigmoid'))  
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    model.fit(X_train, y_train, epochs=10, batch_size=32, validation_split=0.2, verbose=0)
    dnn_output = model.predict(X_test)
    # Assuming dnn_output is binary, you might need to threshold it
    dnn_output = (dnn_output > 0.5).astype(int)
    return dnn_output

def integrate_outputs(fuzzy_output, dnn_output):
    # Ensure both arrays have the same data type
    fuzzy_output = fuzzy_output.astype(np.int32)
    dnn_output = dnn_output.astype(np.int32)

    # Reshape the arrays if necessary to ensure compatible shapes
    if fuzzy_output.shape != dnn_output.shape:
        # Example: Reshape dnn_output to match the shape of fuzzy_output
        dnn_output = np.resize(dnn_output, fuzzy_output.shape)
    fused_output = np.bitwise_and(fuzzy_output, dnn_output)  
    return fused_output


def trainFusedModel():
    global X_train, X_test, y_train, y_test
    global model1
    global f_accuracy, f_precision, f_recall, f_fscore
    # Generate fuzzy logic output
    fuzzy_logic_output_train = fuzzy_logic_function(X_train)
    fuzzy_logic_output_test = fuzzy_logic_function(X_test)

    # Train and predict with DNN
    dnn_output_train = train_and_predict_dnn(X_train, y_train, X_train)
    dnn_output_test = train_and_predict_dnn(X_train, y_train, X_test)

    # Integrate fuzzy logic and DNN outputs
    fused_output_train = integrate_outputs(fuzzy_logic_output_train, dnn_output_train)
    fused_output_test = integrate_outputs(fuzzy_logic_output_test, dnn_output_test)

    # Reshape fused_output_train to match the expected input shape of the model
    fused_output_train_reshaped = fused_output_train.reshape(-1, 1)  # Reshape to (num_samples, 1)

    # Define and train a model using the fused output
    model1 = Sequential()
    model1.add(Dense(128, input_dim=fused_output_train_reshaped.shape[1], activation='relu'))
    model1.add(Dense(1, activation='sigmoid'))
    model1.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    
    
    # Reshape fused_output_test for validation data
    fused_output_test_reshaped = fused_output_test.reshape(-1, 1)  # Reshape to (num_samples, 1)
    
    # Train the model
    history = model1.fit(fused_output_train_reshaped, y_train, epochs=10, batch_size=32, validation_data=(fused_output_test_reshaped, y_test), verbose=0)


    # Predict probabilities on test data
    y_pred_prob = model1.predict(fused_output_test_reshaped)
    # Threshold probabilities to get binary predictions
    y_pred = (y_pred_prob > 0.5).astype(int)

    # Calculate confusion matrix
    conf_matrix = confusion_matrix(y_test, y_pred)

    # Calculate specificity and sensitivity
    tn, fp, fn, tp = conf_matrix.ravel()
    f_sensitivity = tp / (tp + fn)
    f_specificity = tn / (tn + fp)

    # Calculate precision, recall, and f1-score
    f_precision = precision_score(y_test, y_pred,average='macro') * 100
    f_recall = recall_score(y_test, y_pred,average='macro') * 100
    f_fscore = f1_score(y_test, y_pred,average='macro') * 100

    # Calculate accuracy
    f_accuracy = history.history['val_accuracy'][-1] * 100

    # Display results
    name = "Fused Algorithm"
    text.insert(END, name + " Sensitivity  : " + str(f_sensitivity) + "\n")
    text.insert(END, name + " Specificity  : " + str(f_specificity) + "\n")
    text.insert(END, name + " Precision    : " + str(f_precision) + "\n")
    text.insert(END, name + " Recall       : " + str(f_recall) + "\n")
    text.insert(END, name + " F1-Score     : " + str(f_fscore) + "\n")
    text.insert(END, name + " Accuracy     : " + str(f_accuracy) + "\n\n")
    # Plot confusion matrix
    LABELS = ['Fresh Fish', 'Infected Fish']
    plt.figure(figsize=(5, 5))
    ax = sns.heatmap(conf_matrix, xticklabels=LABELS, yticklabels=LABELS, annot=True, cmap="Pastel1", fmt="d")
    ax.set_ylim([0, 2])
    for _, spine in ax.spines.items():
        spine.set_visible(True)
    ax.tick_params(axis='both', which='major', labelsize=10)
    ax.set_xticklabels(ax.get_xticklabels(), fontsize=10, fontfamily='Georgia')
    ax.set_yticklabels(ax.get_yticklabels(), fontsize=10, fontfamily='Georgia')
    ax.set_title(name + " Confusion matrix", fontsize=12, fontfamily='Georgia')
    plt.xlabel('Predicted class', fontsize=10, fontfamily='Georgia')
    plt.ylabel('True class', fontsize=10, fontfamily='Georgia')
    plt.show()

def graph():
    accuracy_list = accuracy[:5]
    precision_list = precision[:5]
    recall_list = recall[:5]
    fscore_list = fscore[:5]

    # Calculate and append metrics for fused model
    fused_accuracy = f_accuracy  # Example accuracy value for fused model
    fused_precision = f_precision  # Example precision value for fused model
    fused_recall = f_recall  # Example recall value for fused model
    fused_fscore = f_fscore # Example fscore value for fused model

    # Append metrics of fused model to respective lists
    accuracy_list.append(fused_accuracy)
    precision_list.append(fused_precision)
    recall_list.append(fused_recall)
    fscore_list.append(fused_fscore)

    df = pd.DataFrame([
        ['Decision Tree', 'Accuracy', accuracy_list[0]],
        ['Decision Tree', 'Precision', precision_list[0]],
        ['Decision Tree', 'Recall', recall_list[0]],
        ['Decision Tree', 'FScore', fscore_list[0]],
        ['Logistic Regression', 'Accuracy', accuracy_list[1]],
        ['Logistic Regression', 'Precision', precision_list[1]],
        ['Logistic Regression', 'Recall', recall_list[1]],
        ['Logistic Regression', 'FScore', fscore_list[1]],
        ['Naive Bayes', 'Accuracy', accuracy_list[2]],
        ['Naive Bayes', 'Precision', precision_list[2]],
        ['Naive Bayes', 'Recall', recall_list[2]],
        ['Naive Bayes', 'FScore', fscore_list[2]],
        ['SVM', 'Accuracy', accuracy_list[3]],
        ['SVM', 'Precision', precision_list[3]],
        ['SVM', 'Recall', recall_list[3]],
        ['SVM', 'FScore', fscore_list[3]],
        ['K-Means', 'Accuracy', accuracy_list[4]],
        ['K-Means', 'Precision', precision_list[4]],
        ['K-Means', 'Recall', recall_list[4]],
        ['K-Means', 'FScore', fscore_list[4]],
        ['Fused Algorithm', 'Accuracy', accuracy_list[5]],
        ['Fused Algorithm', 'Precision', precision_list[5]],
        ['Fused Algorithm', 'Recall', recall_list[5]],
        ['Fused Algorithm', 'FScore', fscore_list[5]],
    ], columns=['Algorithms', 'Metrics', 'Value'])

    # Pivot the data to plot it
    df_pivot = df.pivot(index='Metrics', columns='Algorithms', values='Value')

    ax = df_pivot.plot(kind='bar', figsize=(10, 6), colormap='tab20b')

    # Set plot labels and title
    ax.set_xlabel('Metrics', fontname='Georgia', fontsize=12)
    ax.set_ylabel('Value', fontname='Georgia', fontsize=12)
    ax.set_title('Comparison of Algorithms', fontname='Georgia', fontsize=14)


    # Set font for tick labels
    plt.xticks(fontname='Georgia', fontsize=10)
    plt.yticks(fontname='Georgia', fontsize=10)

    # Show the plot
    plt.show()


# Assuming 'main' is your tkinter main window or frame
status_label = Label(main, text="", font=('League Spartan', 13, 'bold'), fg="darkslateblue")
status_label.place(x=10, y=600)  # Adjust the coordinates as per your layout

def predict():
    global model1
    filename = filedialog.askopenfilename(initialdir="testImages")
    img = cv2.imread(filename)
    img = cv2.resize(img, (150, 150), interpolation=cv2.INTER_CUBIC)
    image_bw = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(clipLimit=5)
    img = clahe.apply(image_bw) + 30
    img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    img = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)
    temp = []
    temp.append(img)
    temp = np.asarray(temp)
    temp = temp.astype('float32') / 255
    temp_reshaped = temp.reshape(-1, 1)
    predict_prob = model1.predict(temp_reshaped)
    predict = np.argmax(predict_prob, axis=1)[0]
    labels = ["Fresh Fish", "Infected Fish"]
    img = cv2.imread(filename)
    img = cv2.resize(img, (400, 400))
    status_text = "Fish Predicted As " + labels[predict]
    status_label.config(text=status_text)
    status_label.update()  # Update the label to reflect the changes

    # Display the image
    cv2.imshow("Fish Predicted as " + labels[predict], img)
    cv2.waitKey(0)
    
    
font = ('League Spartan', 25, 'bold')
title = Label(main, text='FISH DISEASE DETECTION')
title.config(bg='thistle', fg='black')  
title.config(font=font)           
title.config(height=3, width=60)       
title.place(x=0,y=5)

font1 = ('League Spartan', 13, 'bold')
ff = ('League Spartan', 12, 'bold')

l1 = Label(main, text='Dataset Location:')
l1.config(font=font1)
l1.place(x=50,y=100)

tf1 = Entry(main,width=60)
tf1.config(font=font1)
tf1.place(x=230,y=100)

uploadButton = TkinterCustomButton(text="Upload Fish Dataset", width=200, corner_radius=10, command=uploadDataset)
uploadButton.place(x=50,y=150)

preprocessButton = TkinterCustomButton(text="Run CLAHE", width=200, corner_radius=10, command=preprocessDataset)
preprocessButton.place(x=300,y=150)

dtButton = TkinterCustomButton(text="Decision Tree", width=200, corner_radius=10, command=TrainDT)
dtButton.place(x=550,y=150)

lrButton = TkinterCustomButton(text="Logistic Regression", width=200, corner_radius=10, command=TrainLR)
lrButton.place(x=50,y=200)

nbButton = TkinterCustomButton(text="Naive Bayes", width=200, corner_radius=10, command=trainNaiveBayes)
nbButton.place(x=300,y=200)

svmButton = TkinterCustomButton(text="Support Vector Machine", width=200, corner_radius=10, command=trainSVM)
svmButton.place(x=800,y=150)

kmeansButton = TkinterCustomButton(text="K-Means", width=200, corner_radius=10, command=trainKMeans)
kmeansButton.place(x=550, y=200)

fusedModelButton = TkinterCustomButton(text="Fused Model", width=200, corner_radius=10, command=trainFusedModel)
fusedModelButton.place(x=800 , y=200)

graphButton = TkinterCustomButton(text="Comparison Graph", width=200, corner_radius=10, command=graph)
graphButton.place(x=150,y=250)

predictButton = TkinterCustomButton(text="Predict Fish Status", width=200, corner_radius=10, command=predict)
predictButton.place(x=650,y=250)


font1 = ('League Spartan', 13, 'bold')
text=Text(main,height=10,width=120)
scroll=Scrollbar(text)
text.configure(yscrollcommand=scroll.set)
text.place(x=10,y=300)
text.config(font=font1)

main.config(bg='thistle')
main.mainloop()
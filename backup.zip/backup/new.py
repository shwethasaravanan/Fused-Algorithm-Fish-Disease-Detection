import cv2
import os
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import SVC
from sklearn.cluster import KMeans
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tkinter import filedialog, messagebox, simpledialog, Tk, Text, END
from CustomButton import TkinterCustomButton  # Assuming you have a custom button module

main = Tk()
main.title("FISH DISEASE DETECTION")
main.geometry("1200x1000")

global X_train, X_test, y_train, y_test


def preprocess_image(img_path):
    img = cv2.imread(img_path)
    img = cv2.resize(img, (250, 250), interpolation=cv2.INTER_CUBIC)
    image_bw = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(clipLimit=5)
    img = clahe.apply(image_bw) + 30
    img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    img = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)
    return img.ravel()


def preprocess_dataset(augmented_images_dir):
    X, Y = [], []

    for root, _, files in os.walk(augmented_images_dir):
        for file in files:
            if file.endswith(".png"):
                img_path = os.path.join(root, file)
                label = 1 if 'InfectedFish' in root else 0
                img_features = preprocess_image(img_path)
                X.append(img_features)
                Y.append(label)

    X = np.array(X)
    Y = np.array(Y)

    return train_test_split(X, Y, test_size=0.5)


def test(model, name):
    predict = model.predict(X_test)
    acc = accuracy_score(y_test, predict) * 100
    p = precision_score(y_test, predict, average='macro') * 100
    r = recall_score(y_test, predict, average='macro') * 100
    f = f1_score(y_test, predict, average='macro') * 100
    cm = confusion_matrix(y_test, predict)

    # Display metrics
    print(f"{name} Accuracy: {acc}")
    print(f"{name} Precision: {p}")
    print(f"{name} Recall: {r}")
    print(f"{name} F1-Score: {f}")

    # Plot confusion matrix
    LABELS = ['Fresh Fish', 'Infected Fish']
    conf_matrix = confusion_matrix(y_test, predict)
    plt.figure(figsize=(5, 5))
    ax = sns.heatmap(conf_matrix, xticklabels=LABELS, yticklabels=LABELS, annot=True, cmap="Pastel1", fmt="d")
    ax.set_ylim([0, 2])
    plt.title(f"{name} Confusion Matrix")
    plt.xlabel('Predicted class')
    plt.ylabel('True class')
    plt.show()


def train_decision_tree():
    dt_cls = DecisionTreeClassifier()
    dt_cls.fit(X_train, y_train)
    test(dt_cls, "Decision Tree Algorithm")


def train_logistic_regression():
    lr_cls = LogisticRegression()
    lr_cls.fit(X_train, y_train)
    test(lr_cls, "Logistic Regression Algorithm")


def train_naive_bayes():
    nb_cls = MultinomialNB()
    nb_cls.fit(X_train, y_train)
    test(nb_cls, "Naive Bayes Algorithm")


def train_svm():
    svm_cls = SVC(kernel='linear')
    svm_cls.fit(X_train, y_train)
    test(svm_cls, "SVM Algorithm")


def train_kmeans():
    kmeans = KMeans(n_clusters=2, random_state=42)
    kmeans.fit(X_train)
    test(kmeans, "K-Means Algorithm")


def train_fused_model():
    # Implement your fused model training here
    pass


# Example usage
augmented_images_dir = r"C:\Users\Shwetha\Desktop\backup\aug"
X_train, X_test, y_train, y_test = preprocess_dataset(augmented_images_dir)
train_decision_tree()
train_logistic_regression()
train_naive_bayes()
train_svm()
train_kmeans()
# train_fused_model()

main.mainloop()

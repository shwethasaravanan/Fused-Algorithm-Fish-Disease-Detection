import numpy as np
import cv2
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import load_model
from sklearn.metrics import classification_report, confusion_matrix

# Load your fused model
fused_model = load_model("C:/Users/Shwetha/Desktop/backup/fusedmodel.h5")


# Load your input data
X = np.load("model/X.npy")
Y = np.load("model/Y.npy")

# Preprocess your input data
X = X.astype('float32') / 255

# Shuffle and split your data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.5, random_state=42)

# Make predictions using the fused model
y_pred_prob = fused_model.predict(X_test)
y_pred = np.argmax(y_pred_prob, axis=1)

# Print confusion matrix and classification report
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))





